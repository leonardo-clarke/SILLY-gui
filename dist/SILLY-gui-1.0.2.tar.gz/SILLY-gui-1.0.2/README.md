# SILLY-gui
Spectral Interface for Line-fitting quickLY (SILLY) is a program that helps the user to get a rough idea of emission/absorption line parameters from a spectrum.
